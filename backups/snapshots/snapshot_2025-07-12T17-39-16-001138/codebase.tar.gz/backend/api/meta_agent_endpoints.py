#!/usr/bin/env python3
"""
Enhanced Meta Agent API Endpoints
Provides REST API endpoints for monitoring and controlling the enhanced meta agent.
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks, WebSocket
from fastapi.responses import JSONResponse
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import json
import asyncio
from pathlib import Path
import sys
import os

# Add project root to path
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..'))

from agents.enhanced_meta_agent import enhanced_meta_agent
from core.openai_manager import openai_manager
from core.central_event_bus import central_event_bus
from utils.logger import logger
from utils.rollback_manager import rollback_manager

router = APIRouter(prefix="/api/meta-agent", tags=["Enhanced Meta Agent"])

@router.post("/chat")
async def chat_with_meta_agent(query: Dict[str, Any]):
    """
    Chat with the meta agent system for system administration and control.
    This allows natural language interaction with the meta agent for:
    - System status and performance queries
    - Administrative commands
    - Performance reports
    - System improvements and optimizations
    - Agent management
    """
    try:
        user_query = query.get("query", "")
        
        # Process the query with LLM-based meta agent
        result = await process_meta_agent_query(user_query)
        
        return {
            "status": "success",
            "data": result,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error in meta agent chat: {e}")
        raise HTTPException(status_code=500, detail=f"Error processing query: {str(e)}")

async def process_meta_agent_query(query: str) -> Dict[str, Any]:
    """
    Process a natural language query for the meta agent system using LLM.
    """
    try:
        # Get system context
        system_context = await get_system_context()
        
        # Create LLM prompt
        prompt = create_meta_agent_prompt(query, system_context)
        
        # Get LLM response
        llm_response = await get_llm_response(prompt)
        
        # Parse and enhance the response
        result = parse_meta_agent_response(llm_response, system_context)
        
        return result
        
    except Exception as e:
        logger.error(f"Meta agent query processing failed: {e}")
        # Fallback response
        return {
            "answer": "I'm sorry, I'm having trouble processing your request right now. Please try again in a moment.",
            "suggestions": [
                "Check system status",
                "Get performance report",
                "Show recent improvements",
                "List active agents"
            ],
            "confidence": 0.5,
            "action_required": False
        }

async def get_system_context() -> Dict[str, Any]:
    """Get comprehensive system context for the meta agent."""
    try:
        # Get system status
        system_status = enhanced_meta_agent.get_system_status()
        
        # Get recent metrics
        import sqlite3
        db_path = Path("meta_agent_data/enhanced_meta_agent.db")
        recent_metrics = []
        
        if db_path.exists():
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Get last 10 metrics
            cursor.execute('''
                SELECT timestamp, total_agents, active_agents, failed_agents, 
                       avg_response_time, avg_success_rate, system_cpu_usage, 
                       system_memory_usage, total_errors, total_insights, 
                       research_cycles_completed, performance_score
                FROM system_metrics 
                ORDER BY timestamp DESC
                LIMIT 10
            ''')
            
            rows = cursor.fetchall()
            for row in rows:
                recent_metrics.append({
                    "timestamp": row[0],
                    "total_agents": row[1],
                    "active_agents": row[2],
                    "failed_agents": row[3],
                    "avg_response_time": row[4],
                    "avg_success_rate": row[5],
                    "system_cpu_usage": row[6],
                    "system_memory_usage": row[7],
                    "total_errors": row[8],
                    "total_insights": row[9],
                    "research_cycles_completed": row[10],
                    "performance_score": row[11]
                })
            
            conn.close()
        
        # Get recent improvements
        recent_improvements = []
        if db_path.exists():
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT id, type, priority, title, description, status, confidence
                FROM system_improvements 
                ORDER BY created_at DESC
                LIMIT 5
            ''')
            
            rows = cursor.fetchall()
            for row in rows:
                recent_improvements.append({
                    "id": row[0],
                    "type": row[1],
                    "priority": row[2],
                    "title": row[3],
                    "description": row[4],
                    "status": row[5],
                    "confidence": row[6]
                })
            
            conn.close()
        
        # Get recent events
        recent_events = central_event_bus.get_recent_events(limit=10)
        
        return {
            "system_status": system_status,
            "recent_metrics": recent_metrics,
            "recent_improvements": recent_improvements,
            "recent_events": recent_events,
            "current_time": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error getting system context: {e}")
        return {
            "system_status": {},
            "recent_metrics": [],
            "recent_improvements": [],
            "recent_events": [],
            "current_time": datetime.now().isoformat()
        }

def create_meta_agent_prompt(query: str, context: Dict[str, Any]) -> str:
    """Create a comprehensive prompt for the meta agent LLM."""
    
    # Format recent metrics
    metrics_text = ""
    if context["recent_metrics"]:
        latest_metrics = context["recent_metrics"][0]
        metrics_text = f"""
Latest System Metrics:
- Total Agents: {latest_metrics['total_agents']}
- Active Agents: {latest_metrics['active_agents']}
- Failed Agents: {latest_metrics['failed_agents']}
- Avg Response Time: {latest_metrics['avg_response_time']:.2f}s
- Success Rate: {latest_metrics['avg_success_rate']:.2%}
- CPU Usage: {latest_metrics['system_cpu_usage']:.1f}%
- Memory Usage: {latest_metrics['system_memory_usage']:.1f}%
- Performance Score: {latest_metrics['performance_score']:.2f}
- Total Errors: {latest_metrics['total_errors']}
- Research Cycles: {latest_metrics['research_cycles_completed']}
"""
    
    # Format recent improvements
    improvements_text = ""
    if context["recent_improvements"]:
        improvements_text = "\nRecent System Improvements:\n"
        for imp in context["recent_improvements"]:
            improvements_text += f"- {imp['title']} ({imp['type']}, {imp['priority']}, {imp['status']}, confidence: {imp['confidence']:.2f})\n"
    
    # Format recent events
    events_text = ""
    if context["recent_events"]:
        events_text = "\nRecent System Events:\n"
        for event in context["recent_events"][:5]:
            events_text += f"- {event.get('title', 'Unknown')} ({event.get('source', 'Unknown')})\n"
    
    prompt = f"""You are the Meta Agent Administrator for the RoboInvest autonomous trading system. You have full access to monitor, control, and optimize the entire multi-agent ecosystem.

System Context:
{metrics_text}{improvements_text}{events_text}

Your capabilities include:
1. **System Monitoring**: Check agent health, performance metrics, resource usage
2. **Performance Analysis**: Analyze trends, identify bottlenecks, suggest optimizations
3. **Administrative Control**: Start/stop agents, approve/reject improvements, manage resources
4. **Reporting**: Generate performance reports, daily summaries, system insights
5. **Troubleshooting**: Diagnose issues, suggest fixes, coordinate recovery
6. **Strategic Planning**: Make recommendations for system improvements and growth

User Query: "{query}"

Please provide a helpful, intelligent response that:
1. Directly addresses the user's question or request
2. Provides relevant system information and insights
3. Suggests appropriate actions if needed
4. Offers follow-up questions or commands the user might want to try

Respond in JSON format with these keys:
- answer: A natural, helpful response to the user's query
- suggestions: List of follow-up commands or questions the user might want to try
- confidence: Your confidence in the response (0.0-1.0)
- action_required: Boolean indicating if any system action is needed
- system_insights: Any additional insights about the system state
- recommended_actions: List of specific actions you recommend (if any)

Be conversational, authoritative, and provide actionable insights. You are the system administrator, so be confident and helpful."""

    return prompt

async def get_llm_response(prompt: str) -> Dict[str, Any]:
    """Get response from the LLM for meta agent queries."""
    try:
        response = openai_manager.chat_completion([
            {"role": "system", "content": "You are a helpful meta agent administrator. Always respond in valid JSON format."},
            {"role": "user", "content": prompt}
        ])
        
        # Parse the JSON response
        content = response.get("content", "{}")
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            # If JSON parsing fails, create a structured response
            return {
                "answer": content,
                "suggestions": [
                    "Check system status",
                    "Get performance report",
                    "Show recent improvements"
                ],
                "confidence": 0.5,
                "action_required": False,
                "system_insights": "LLM response could not be parsed as JSON",
                "recommended_actions": []
            }
            
    except Exception as e:
        logger.error(f"LLM call failed: {e}")
        raise

def parse_meta_agent_response(llm_response: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    """Parse and enhance the meta agent LLM response."""
    
    # Extract basic response
    answer = llm_response.get("answer", "I couldn't process your query. Please try again.")
    suggestions = llm_response.get("suggestions", [])
    confidence = llm_response.get("confidence", 0.5)
    action_required = llm_response.get("action_required", False)
    system_insights = llm_response.get("system_insights", "")
    recommended_actions = llm_response.get("recommended_actions", [])
    
    # Add default suggestions if none provided
    if not suggestions:
        suggestions = [
            "Check system status",
            "Get performance report",
            "Show recent improvements",
            "List active agents",
            "Generate daily report"
        ]
    
    # Add insights to the answer if available
    if system_insights:
        answer += f"\n\nSystem Insights: {system_insights}"
    
    return {
        "answer": answer,
        "suggestions": suggestions,
        "confidence": confidence,
        "action_required": action_required,
        "recommended_actions": recommended_actions
    }

@router.get("/status")
async def get_meta_agent_status():
    """Get the current status of the enhanced meta agent."""
    try:
        status = enhanced_meta_agent.get_system_status()
        return {
            "status": "success",
            "data": status,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting meta agent status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/metrics")
async def get_system_metrics(hours: int = 24):
    """Get system metrics for the specified time period."""
    try:
        # Get metrics from database
        import sqlite3
        db_path = Path("meta_agent_data/enhanced_meta_agent.db")
        
        if not db_path.exists():
            return {
                "status": "success",
                "data": [],
                "message": "No metrics data available yet"
            }
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Get metrics from last N hours
        cutoff_time = datetime.now() - timedelta(hours=hours)
        
        cursor.execute('''
            SELECT timestamp, total_agents, active_agents, failed_agents, 
                   avg_response_time, avg_success_rate, system_cpu_usage, 
                   system_memory_usage, total_errors, total_insights, 
                   research_cycles_completed, performance_score
            FROM system_metrics 
            WHERE timestamp > ?
            ORDER BY timestamp DESC
        ''', (cutoff_time.isoformat(),))
        
        rows = cursor.fetchall()
        conn.close()
        
        metrics = []
        for row in rows:
            metrics.append({
                "timestamp": row[0],
                "total_agents": row[1],
                "active_agents": row[2],
                "failed_agents": row[3],
                "avg_response_time": row[4],
                "avg_success_rate": row[5],
                "system_cpu_usage": row[6],
                "system_memory_usage": row[7],
                "total_errors": row[8],
                "total_insights": row[9],
                "research_cycles_completed": row[10],
                "performance_score": row[11]
            })
        
        return {
            "status": "success",
            "data": metrics,
            "count": len(metrics),
            "time_period_hours": hours
        }
        
    except Exception as e:
        logger.error(f"Error getting system metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/improvements")
async def get_system_improvements(status: Optional[str] = None):
    """Get system improvement suggestions."""
    try:
        import sqlite3
        db_path = Path("meta_agent_data/enhanced_meta_agent.db")
        
        if not db_path.exists():
            return {
                "status": "success",
                "data": [],
                "message": "No improvements data available yet"
            }
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        if status:
            cursor.execute('''
                SELECT id, type, priority, title, description, affected_components,
                       estimated_impact, implementation_plan, confidence, created_at, 
                       status, assigned_agent, completion_time
                FROM system_improvements 
                WHERE status = ?
                ORDER BY created_at DESC
            ''', (status,))
        else:
            cursor.execute('''
                SELECT id, type, priority, title, description, affected_components,
                       estimated_impact, implementation_plan, confidence, created_at, 
                       status, assigned_agent, completion_time
                FROM system_improvements 
                ORDER BY created_at DESC
            ''')
        
        rows = cursor.fetchall()
        conn.close()
        
        improvements = []
        for row in rows:
            improvements.append({
                "id": row[0],
                "type": row[1],
                "priority": row[2],
                "title": row[3],
                "description": row[4],
                "affected_components": json.loads(row[5]) if row[5] else [],
                "estimated_impact": json.loads(row[6]) if row[6] else {},
                "implementation_plan": json.loads(row[7]) if row[7] else {},
                "confidence": row[8],
                "created_at": row[9],
                "status": row[10],
                "assigned_agent": row[11],
                "completion_time": row[12]
            })
        
        return {
            "status": "success",
            "data": improvements,
            "count": len(improvements),
            "filtered_by_status": status
        }
        
    except Exception as e:
        logger.error(f"Error getting system improvements: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/improvements/{improvement_id}/approve")
async def approve_improvement(improvement_id: str):
    """Approve a system improvement for implementation."""
    try:
        # Find the improvement
        improvement = None
        for imp in enhanced_meta_agent.system_improvements:
            if imp.id == improvement_id:
                improvement = imp
                break
        
        if not improvement:
            raise HTTPException(status_code=404, detail="Improvement not found")
        
        if improvement.status != "pending":
            raise HTTPException(status_code=400, detail=f"Improvement is not pending (current status: {improvement.status})")
        
        # Approve the improvement
        improvement.status = "approved"
        
        # Update database
        import sqlite3
        db_path = Path("meta_agent_data/enhanced_meta_agent.db")
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE system_improvements 
            SET status = ?
            WHERE id = ?
        ''', ("approved", improvement_id))
        
        conn.commit()
        conn.close()
        
        logger.info(f"✅ Approved improvement: {improvement.title}")
        
        return {
            "status": "success",
            "message": f"Improvement '{improvement.title}' approved for implementation",
            "improvement_id": improvement_id
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error approving improvement: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/improvements/{improvement_id}/reject")
async def reject_improvement(improvement_id: str, reason: str = "No reason provided"):
    """Reject a system improvement."""
    try:
        # Find the improvement
        improvement = None
        for imp in enhanced_meta_agent.system_improvements:
            if imp.id == improvement_id:
                improvement = imp
                break
        
        if not improvement:
            raise HTTPException(status_code=404, detail="Improvement not found")
        
        if improvement.status != "pending":
            raise HTTPException(status_code=400, detail=f"Improvement is not pending (current status: {improvement.status})")
        
        # Reject the improvement
        improvement.status = "rejected"
        
        # Update database
        import sqlite3
        db_path = Path("meta_agent_data/enhanced_meta_agent.db")
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE system_improvements 
            SET status = ?
            WHERE id = ?
        ''', ("rejected", improvement_id))
        
        conn.commit()
        conn.close()
        
        logger.info(f"❌ Rejected improvement: {improvement.title} (Reason: {reason})")
        
        return {
            "status": "success",
            "message": f"Improvement '{improvement.title}' rejected",
            "improvement_id": improvement_id,
            "reason": reason
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error rejecting improvement: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/control/start")
async def start_meta_agent():
    """Start the enhanced meta agent monitoring."""
    try:
        if enhanced_meta_agent.active_monitoring:
            return {
                "status": "success",
                "message": "Enhanced meta agent is already running"
            }
        
        # Start monitoring in background
        asyncio.create_task(enhanced_meta_agent.start_continuous_monitoring())
        
        return {
            "status": "success",
            "message": "Enhanced meta agent monitoring started"
        }
        
    except Exception as e:
        logger.error(f"Error starting meta agent: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/control/stop")
async def stop_meta_agent():
    """Stop the enhanced meta agent monitoring."""
    try:
        if not enhanced_meta_agent.active_monitoring:
            return {
                "status": "success",
                "message": "Enhanced meta agent is not running"
            }
        
        enhanced_meta_agent.stop_monitoring()
        
        return {
            "status": "success",
            "message": "Enhanced meta agent monitoring stopped"
        }
        
    except Exception as e:
        logger.error(f"Error stopping meta agent: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/reports")
async def get_system_reports():
    """Get available system reports."""
    try:
        reports_dir = Path("meta_agent_data/system_reports")
        
        if not reports_dir.exists():
            return {
                "status": "success",
                "data": [],
                "message": "No reports available yet"
            }
        
        reports = []
        for report_file in reports_dir.glob("system_report_*.json"):
            try:
                with open(report_file, 'r') as f:
                    report_data = json.load(f)
                
                reports.append({
                    "filename": report_file.name,
                    "timestamp": report_data.get("timestamp", ""),
                    "performance_score": report_data.get("system_health", {}).get("performance_score", 0),
                    "active_agents": report_data.get("system_health", {}).get("active_agents", 0),
                    "failed_agents": report_data.get("system_health", {}).get("failed_agents", 0)
                })
            except Exception as e:
                logger.error(f"Error reading report {report_file}: {e}")
        
        # Sort by timestamp (newest first)
        reports.sort(key=lambda x: x["timestamp"], reverse=True)
        
        return {
            "status": "success",
            "data": reports,
            "count": len(reports)
        }
        
    except Exception as e:
        logger.error(f"Error getting system reports: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/reports/{filename}")
async def get_system_report(filename: str):
    """Get a specific system report."""
    try:
        report_path = Path("meta_agent_data/system_reports") / filename
        
        if not report_path.exists():
            raise HTTPException(status_code=404, detail="Report not found")
        
        with open(report_path, 'r') as f:
            report_data = json.load(f)
        
        return {
            "status": "success",
            "data": report_data,
            "filename": filename
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting system report: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/agent-performance")
async def get_agent_performance(agent_name: Optional[str] = None, hours: int = 24):
    """Get agent performance history."""
    try:
        import sqlite3
        db_path = Path("meta_agent_data/enhanced_meta_agent.db")
        
        if not db_path.exists():
            return {
                "status": "success",
                "data": [],
                "message": "No performance data available yet"
            }
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cutoff_time = datetime.now() - timedelta(hours=hours)
        
        if agent_name:
            cursor.execute('''
                SELECT agent_name, timestamp, response_time, success_rate, 
                       error_count, insights_generated, memory_usage, cpu_usage
                FROM agent_performance_history 
                WHERE agent_name = ? AND timestamp > ?
                ORDER BY timestamp DESC
            ''', (agent_name, cutoff_time.isoformat()))
        else:
            cursor.execute('''
                SELECT agent_name, timestamp, response_time, success_rate, 
                       error_count, insights_generated, memory_usage, cpu_usage
                FROM agent_performance_history 
                WHERE timestamp > ?
                ORDER BY timestamp DESC
            ''', (cutoff_time.isoformat(),))
        
        rows = cursor.fetchall()
        conn.close()
        
        performance_data = []
        for row in rows:
            performance_data.append({
                "agent_name": row[0],
                "timestamp": row[1],
                "response_time": row[2],
                "success_rate": row[3],
                "error_count": row[4],
                "insights_generated": row[5],
                "memory_usage": row[6],
                "cpu_usage": row[7]
            })
        
        return {
            "status": "success",
            "data": performance_data,
            "count": len(performance_data),
            "filtered_by_agent": agent_name,
            "time_period_hours": hours
        }
        
    except Exception as e:
        logger.error(f"Error getting agent performance: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/trigger-analysis")
async def trigger_system_analysis():
    """Manually trigger a system analysis."""
    try:
        # This would trigger an immediate analysis
        # For now, we'll just return a success message
        logger.info("🔍 Manual system analysis triggered")
        
        return {
            "status": "success",
            "message": "System analysis triggered",
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error triggering system analysis: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/health")
async def get_meta_agent_health():
    """Get detailed health information about the meta agent."""
    try:
        health_info = {
            "meta_agent_active": enhanced_meta_agent.active_monitoring,
            "monitoring_interval_seconds": enhanced_meta_agent.monitoring_interval,
            "metrics_retention_hours": enhanced_meta_agent.metrics_retention_hours,
            "improvement_threshold": enhanced_meta_agent.improvement_threshold,
            "performance_thresholds": enhanced_meta_agent.performance_thresholds,
            "total_improvements": len(enhanced_meta_agent.system_improvements),
            "metrics_history_count": len(enhanced_meta_agent.system_metrics_history),
            "improvement_queue_count": len(enhanced_meta_agent.improvement_queue),
            "database_path": str(enhanced_meta_agent.db_path),
            "database_exists": enhanced_meta_agent.db_path.exists(),
            "timestamp": datetime.now().isoformat()
        }
        
        return {
            "status": "success",
            "data": health_info
        }
        
    except Exception as e:
        logger.error(f"Error getting meta agent health: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.websocket("/ws/meta-agent/chat")
async def meta_agent_chat_ws(websocket: WebSocket):
    await websocket.accept()
    try:
        # Receive the initial message (should contain the query)
        data = await websocket.receive_json()
        user_query = data.get("query", "")

        # Mock chain-of-thought generator (replace with real agent logic)
        async def chain_of_thought_steps(query):
            steps = [
                f"Received query: {query}",
                "Analyzing system context...",
                "Identifying relevant agents...",
                "Generating improvement suggestions...",
                "Waiting for approval (if required)...",
                "Finalizing response..."
            ]
            for step in steps:
                yield step
                await asyncio.sleep(0.7)
            yield "DONE"

        async for step in chain_of_thought_steps(user_query):
            await websocket.send_json({"step": step})
            if step == "DONE":
                break
    except Exception as e:
        await websocket.send_json({"error": str(e)})
    finally:
        await websocket.close()

@router.get("/snapshots")
async def list_snapshots():
    """List all available system snapshots."""
    try:
        snapshots = rollback_manager.list_snapshots()
        return {
            "status": "success",
            "data": {
                "snapshots": snapshots,
                "total": len(snapshots)
            },
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error listing snapshots: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing snapshots: {str(e)}")

@router.post("/snapshots")
async def create_snapshot(request: Dict[str, Any]):
    """Create a new system snapshot."""
    try:
        description = request.get("description", "Manual snapshot")
        change_type = request.get("change_type", "manual")
        
        snapshot_id = rollback_manager.create_snapshot(description, change_type)
        
        return {
            "status": "success",
            "data": {
                "snapshot_id": snapshot_id,
                "description": description,
                "change_type": change_type
            },
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error creating snapshot: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating snapshot: {str(e)}")

@router.post("/rollback/{snapshot_id}")
async def rollback_to_snapshot(snapshot_id: str):
    """Rollback to a specific snapshot."""
    try:
        success = rollback_manager.rollback_to_snapshot(snapshot_id)
        
        if success:
            return {
                "status": "success",
                "data": {
                    "message": f"Successfully rolled back to snapshot: {snapshot_id}",
                    "snapshot_id": snapshot_id
                },
                "timestamp": datetime.now().isoformat()
            }
        else:
            raise HTTPException(status_code=400, detail=f"Failed to rollback to snapshot: {snapshot_id}")
    except Exception as e:
        logger.error(f"Error rolling back to snapshot {snapshot_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Error rolling back: {str(e)}")

@router.delete("/snapshots/{snapshot_id}")
async def delete_snapshot(snapshot_id: str):
    """Delete a snapshot."""
    try:
        success = rollback_manager.delete_snapshot(snapshot_id)
        
        if success:
            return {
                "status": "success",
                "data": {
                    "message": f"Successfully deleted snapshot: {snapshot_id}",
                    "snapshot_id": snapshot_id
                },
                "timestamp": datetime.now().isoformat()
            }
        else:
            raise HTTPException(status_code=400, detail=f"Failed to delete snapshot: {snapshot_id}")
    except Exception as e:
        logger.error(f"Error deleting snapshot {snapshot_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Error deleting snapshot: {str(e)}")