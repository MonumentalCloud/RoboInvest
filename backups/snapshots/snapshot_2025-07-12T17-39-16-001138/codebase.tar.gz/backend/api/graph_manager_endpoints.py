from fastapi import APIRouter, HTTPException
from typing import List, Dict, Any, Optional
import json
from datetime import datetime
import os
import sys

# Add the parent directory to the path to import from agents
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from agents.research_graph_manager import research_graph_manager
from core.openai_manager import openai_manager
from core.central_event_bus import central_event_bus

router = APIRouter()

# Load research data from the central event bus
def load_research_data():
    """Load research data from the central event bus database"""
    try:
        # Get all research trees from the central event bus
        trees = central_event_bus.get_research_trees()
        
        all_nodes = []
        for tree in trees:
            tree_id = tree["tree_id"]
            nodes = central_event_bus.get_research_tree_nodes(tree_id)
            
            for node in nodes:
                # Add research track info
                node["research_track"] = tree["track_name"]
                all_nodes.append(node)
        
        return all_nodes
    except Exception as e:
        print(f"Error loading research data: {e}")
        return []

@router.post("/graph/query")
async def query_graph(query: Dict[str, Any]):
    """
    Query the research graph intelligently using LLM-based analysis
    """
    try:
        user_query = query.get("query", "")
        research_data = load_research_data()
        
        if not research_data:
            return {
                "status": "success",
                "data": {
                    "answer": "I don't have any research data to analyze yet. Please wait for the research system to generate some data.",
                    "highlighted_nodes": [],
                    "suggestions": [
                        "Check back later for research data",
                        "Start a new research task",
                        "Check system status"
                    ],
                    "node_count": 0,
                    "confidence": 0.0
                },
                "timestamp": datetime.now().isoformat()
            }
        
        # Use LLM-based processing
        results = await process_graph_query_with_llm(user_query, research_data)
        
        return {
            "status": "success",
            "data": results,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing query: {str(e)}")

async def process_graph_query_with_llm(query: str, nodes: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Process a natural language query about the research graph using LLM
    """
    try:
        # First, run the research graph manager analysis to get insights
        analysis_results = research_graph_manager.analyze_research_graph(nodes)
        
        # Prepare context for the LLM
        context = prepare_context_for_llm(nodes, analysis_results)
        
        # Create LLM prompt
        prompt = create_llm_prompt(query, context)
        
        # Get LLM response
        llm_response = await get_llm_response(prompt)
        
        # Parse and enhance the response
        results = parse_llm_response(llm_response, nodes, analysis_results)
        
        return results
        
    except Exception as e:
        print(f"LLM processing failed: {e}")
        # Fallback to rule-based processing
        return process_graph_query_fallback(query, nodes)

def prepare_context_for_llm(nodes: List[Dict[str, Any]], analysis_results: Dict[str, Any]) -> Dict[str, Any]:
    """Prepare context information for the LLM"""
    context = {
        "total_nodes": len(nodes),
        "node_types": {},
        "research_tracks": {},
        "status_distribution": {},
        "confidence_distribution": {},
        "patterns": analysis_results.get("patterns", []),
        "synthesis_opportunities": analysis_results.get("synthesis_opportunities", []),
        "similar_groups": analysis_results.get("similar_groups", [])
    }
    
    # Analyze node distribution
    for node in nodes:
        # Count by type
        node_type = node.get("type", "unknown")
        context["node_types"][node_type] = context["node_types"].get(node_type, 0) + 1
        
        # Count by research track
        track = node.get("research_track", "unknown")
        context["research_tracks"][track] = context["research_tracks"].get(track, 0) + 1
        
        # Count by status
        status = node.get("status", "unknown")
        context["status_distribution"][status] = context["status_distribution"].get(status, 0) + 1
        
        # Count by confidence ranges
        confidence = node.get("confidence")
        if confidence:
            if isinstance(confidence, str):
                try:
                    confidence = float(confidence)
                except:
                    confidence = None
            
            if confidence is not None:
                if confidence > 0.8:
                    context["confidence_distribution"]["high"] = context["confidence_distribution"].get("high", 0) + 1
                elif confidence > 0.6:
                    context["confidence_distribution"]["medium"] = context["confidence_distribution"].get("medium", 0) + 1
                else:
                    context["confidence_distribution"]["low"] = context["confidence_distribution"].get("low", 0) + 1
    
    return context

def create_llm_prompt(query: str, context: Dict[str, Any]) -> str:
    """Create a comprehensive prompt for the LLM"""
    
    # Convert patterns to readable format
    patterns_text = ""
    if context["patterns"]:
        patterns_text = "\n\nDetected Patterns:\n"
        for pattern in context["patterns"]:
            patterns_text += f"- {pattern.pattern_type}: {pattern.description}\n"
    
    # Convert synthesis opportunities to readable format
    synthesis_text = ""
    if context["synthesis_opportunities"]:
        synthesis_text = "\n\nSynthesis Opportunities:\n"
        for opp in context["synthesis_opportunities"]:
            synthesis_text += f"- {opp.type.value}: {opp.title} (confidence: {opp.confidence})\n"
    
    prompt = f"""You are an intelligent research graph assistant. You help users explore and understand a research graph containing {context['total_nodes']} nodes.

Research Graph Context:
- Total nodes: {context['total_nodes']}
- Node types: {dict(context['node_types'])}
- Research tracks: {dict(context['research_tracks'])}
- Status distribution: {dict(context['status_distribution'])}
- Confidence distribution: {dict(context['confidence_distribution'])}{patterns_text}{synthesis_text}

User Query: "{query}"

Please provide a helpful, intelligent response that:
1. Directly addresses the user's question
2. Provides specific insights about the research graph
3. Suggests relevant nodes to highlight (provide node IDs if you can infer them)
4. Offers follow-up questions the user might want to ask
5. Explains any patterns or insights you notice

Respond in JSON format with these keys:
- answer: A natural, helpful response to the user's query
- highlighted_nodes: List of node IDs to highlight (if applicable)
- suggestions: List of follow-up questions the user might ask
- node_count: Number of relevant nodes found
- confidence: Your confidence in the response (0.0-1.0)
- insights: Any additional insights about patterns or trends you notice

Be conversational, helpful, and provide actionable insights."""

    return prompt

async def get_llm_response(prompt: str) -> Dict[str, Any]:
    """Get response from the LLM"""
    try:
        response = openai_manager.chat_completion([
            {"role": "system", "content": "You are a helpful research graph assistant. Always respond in valid JSON format."},
            {"role": "user", "content": prompt}
        ])
        
        # Parse the JSON response
        content = response.get("content", "{}")
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            # If JSON parsing fails, create a structured response
            return {
                "answer": content,
                "highlighted_nodes": [],
                "suggestions": [
                    "Show me active research nodes",
                    "Find synthesis nodes",
                    "What are the most important findings?"
                ],
                "node_count": 0,
                "confidence": 0.5,
                "insights": "LLM response could not be parsed as JSON"
            }
            
    except Exception as e:
        print(f"LLM call failed: {e}")
        raise

def parse_llm_response(llm_response: Dict[str, Any], nodes: List[Dict[str, Any]], analysis_results: Dict[str, Any]) -> Dict[str, Any]:
    """Parse and enhance the LLM response"""
    
    # Extract basic response
    answer = llm_response.get("answer", "I couldn't process your query. Please try again.")
    highlighted_nodes = llm_response.get("highlighted_nodes", [])
    suggestions = llm_response.get("suggestions", [])
    confidence = llm_response.get("confidence", 0.5)
    insights = llm_response.get("insights", "")
    
    # Validate highlighted nodes exist
    valid_nodes = [node_id for node_id in highlighted_nodes if any(node.get("id") == node_id for node in nodes)]
    
    # Add default suggestions if none provided
    if not suggestions:
        suggestions = [
            "Show me active research nodes",
            "Find synthesis nodes", 
            "What are the most important findings?",
            "Show me market analysis nodes",
            "Find nodes with high confidence"
        ]
    
    # Add insights to the answer if available
    if insights:
        answer += f"\n\nInsights: {insights}"
    
    return {
        "answer": answer,
        "highlighted_nodes": valid_nodes,
        "suggestions": suggestions,
        "node_count": len(valid_nodes),
        "confidence": confidence
    }

def process_graph_query_fallback(query: str, nodes: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Fallback rule-based processing if LLM fails
    """
    query_lower = query.lower()
    
    # Initialize results
    results = {
        "answer": "",
        "highlighted_nodes": [],
        "suggestions": [],
        "node_count": 0,
        "confidence": 0.0
    }
    
    # Query patterns (simplified fallback)
    if any(word in query_lower for word in ['active', 'current', 'ongoing']):
        active_nodes = [node for node in nodes if node.get('status') == 'active']
        results.update({
            "answer": f"I found {len(active_nodes)} active research nodes. These represent ongoing research activities and current investigations.",
            "highlighted_nodes": [node['id'] for node in active_nodes],
            "node_count": len(active_nodes),
            "confidence": 0.9,
            "suggestions": [
                "Show me completed research",
                "Find synthesis nodes",
                "What are the high-confidence findings?",
                "Show me market analysis nodes"
            ]
        })
    
    elif any(word in query_lower for word in ['synthesis', 'finding', 'insight']):
        synthesis_nodes = [node for node in nodes if node.get('type') == 'synthesis']
        results.update({
            "answer": f"I found {len(synthesis_nodes)} synthesis nodes. These represent key findings and insights that combine multiple research threads.",
            "highlighted_nodes": [node['id'] for node in synthesis_nodes],
            "node_count": len(synthesis_nodes),
            "confidence": 0.9,
            "suggestions": [
                "Show me market analysis",
                "Find technical analysis nodes",
                "What are the risk assessments?",
                "Show me active research"
            ]
        })
    
    else:
        # Default response
        results.update({
            "answer": f"I understand you're asking about '{query}'. I can help you explore the research graph. Try asking about active research, synthesis findings, market analysis, technical indicators, risk assessments, or high-confidence nodes.",
            "node_count": len(nodes),
            "confidence": 0.5,
            "suggestions": [
                "Show me active research nodes",
                "Find synthesis nodes",
                "What are the most important findings?",
                "Show me market analysis nodes",
                "Find nodes with high confidence",
                "Show me technical analysis",
                "What are the risk factors?"
            ]
        })
    
    return results

@router.get("/graph/stats")
async def get_graph_stats():
    """
    Get overall statistics about the research graph
    """
    try:
        research_data = load_research_data()
        
        # Calculate statistics
        total_nodes = 0
        track_stats = {}
        type_stats = {}
        status_stats = {}
        
        for node in research_data:
            total_nodes += 1
            track = node.get("research_track", "unknown")
            track_stats[track] = track_stats.get(track, 0) + 1
            
            node_type = node.get("type", "unknown")
            type_stats[node_type] = type_stats.get(node_type, 0) + 1
            
            status = node.get("status", "unknown")
            status_stats[status] = status_stats.get(status, 0) + 1
        
        return {
            "status": "success",
            "data": {
                "total_nodes": total_nodes,
                "track_stats": track_stats,
                "type_stats": type_stats,
                "status_stats": status_stats,
                "timestamp": datetime.now().isoformat()
            }
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error getting graph stats: {str(e)}") 